"""Where ripgrep's matcher library is: ``LIBRARY`` (row RT-PHONE-REGEX-SEARCH-SHIPS-ON-ANDROID)."""

from pathlib import Path

LIBRARY = str(Path(__file__).with_name("libproject_files_match.so"))
